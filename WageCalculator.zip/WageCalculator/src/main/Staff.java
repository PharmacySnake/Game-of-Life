package main;

import java.util.ArrayList;
import java.util.List;

public class Staff {

    private List<Employee> staff = new ArrayList<>();

    public Staff() {

    }

    public void addEmployee(Employee employee) {
        this.staff.add(employee);
    }

    public List getStaffList() {
        return this.staff;
    }

    boolean checkID(String string) {
        for (int i = 0; i < this.staff.size(); i++) {
            if (this.staff.get(i).getID().equals(string)) {
                return true;
            }
        }
        return false;
    }
    
    public Employee getEmployeeByName(String name) {
        Employee employee = null;
        for (int i = 0; i < this.staff.size(); i++) {
            if(this.staff.get(i).getName().equals(name)) {
                employee = this.staff.get(i);
            }
        }
        return employee;
    }

    @Override
    public String toString() {
        String list = "";
        for (int i = 0; i < this.staff.size(); i++) {
            list += this.staff.get(i);
        }
        return list;
    }

}
