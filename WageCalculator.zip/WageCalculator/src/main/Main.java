package main;

public class Main {

    public static void main(String[] args) {
        Staff s = new Staff();
        Roster r = new Roster(s);
        CSVreader c = new CSVreader("", r);
        
        c.readCSV();
        WageCalculator w = new WageCalculator(r.getList());
        w.processList();
        System.out.println(w.getSalary());
        
        
        //w.getSalary();
        
        
        //System.out.println(r);
        //System.out.println(s);
        
        
    }

}
