package main;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;

public class CSVreader {

    private FileReader fileReader;
    private BufferedReader buffReader;
    private String file;
    private Roster roster;

    public CSVreader(String file, Roster roster) {
        this.file = file;
        this.file = "C://Users//pimviilboy85//Downloads//recruitment-nut//recruitment-nut (5)/HourList201403.csv";
        this.roster = roster;
    }

    public void readCSV() {
        try {
            this.fileReader = new FileReader(this.file);
            this.buffReader = new BufferedReader(this.fileReader);
            this.buffReader.readLine();
            String stringRead = this.buffReader.readLine();

            while (stringRead != null) {
                String[] line = stringRead.split(",");

                // read the next line
                stringRead = this.buffReader.readLine();

                this.roster.addToList(line);
            }
            this.buffReader.close();

        } catch (IOException ioe) {
            System.out.println(ioe);
        }
    }
}
