package main;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Roster {

    private List<Shift> roster;
    //private Map<String, Shift> roster;
    private Staff staff;
    private Employee newEmployee;
    private Shift shift;

    public Roster(Staff staff) {
        this.roster = new ArrayList<>();
        //this.roster = new HashMap<>();
        this.staff = staff;
    }

    public void addToList(String[] line) {
        //if (!this.staff.getStaffList().contains(line[0])) {
        if (!this.staff.checkID(line[1])) {
            createEmployee(line[0], line[1]);
        }

        createShift(line[0], line[2], line[3], line[4]);

        this.roster.add(this.shift);
        //this.roster.put(getMonth(shift.getDate()), shift);
    }

    public void createEmployee(String name, String id) {
        this.newEmployee = new Employee(name, id);
        this.staff.addEmployee(this.newEmployee);
    }

    public void createShift(String name, String date, String start, String end) {
        this.shift = new Shift(this.staff.getEmployeeByName(name), date, start, end);
    }

    public List listByName(String name) {
        List<Shift> newList = new ArrayList();

        for (int i = 0; i < this.roster.size(); i++) {
            if (this.roster.get(i).getEmployeeByName().contains(name)) {
                newList.add(this.roster.get(i));
            }
        }
        //System.out.println(newList);
        return newList;
    }

    /*public void listByName() {
        
    }*/
    public List listByID(String id) {
        List<Shift> newList = new ArrayList();

        for (int i = 0; i < this.roster.size(); i++) {
            if (this.roster.get(i).getEmployeeByID().contains(id)) {
                newList.add(this.roster.get(i));
            }
        }
        //System.out.println(newList);
        return newList;
    }

    public List listByDate(String date) {
        List<Shift> newList = new ArrayList();

        for (int i = 0; i < this.roster.size(); i++) {
            if (this.roster.get(i).getDate().contains(date)) {
                newList.add(this.roster.get(i));
            }
        }
        //System.out.println(newList);
        return newList;
    }
    
    protected List getList() {
        return this.roster;
    }

    @Override
    public String toString() {
        String list = "";
        for (int i = 0; i < this.roster.size(); i++) {
            list += this.roster.get(i) + "\n";

        }
        return list;
    }

    /*private String getMonth(String date) {
        String[] part = date.split(".");
        
        return part[1];
    }*/

}
