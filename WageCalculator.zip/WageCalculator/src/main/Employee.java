package main;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Employee {

    protected String name;
    protected String id;
    protected Date date = new Date();
    protected String startDate;
    protected DateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy");
    //private Map<String, List> personalRoster;
    //private Roster personalRoster;

    public Employee(String name, String id) {
        this.name = name;
        //  this.sName = sName;
        this.id = id;
        this.startDate = dateFormat.format(date);
        //this.personalRoster = new HashMap<>();
    }

    public String getName() {
        return this.name;
    }

    public String getID() {
        return this.id;
    }

    public String getSDate() {
        return this.startDate;
    }

    public void setName(String newName) {
        this.name = newName;
    }

    public void setID(String newID) {
        this.id = newID;
    }

    @Override
    public String toString() {
        return "Name: " + getName() //+ " " + getSName()
                + "\nStart date: " + getSDate()
                + "\nID: " + getID()
                + "\n\n";
    }
}
