package main;

public class Shift {

    protected Employee employee;
    protected String shiftDate;
    protected String start;
    protected String end;

    public Shift(Employee employee, String shiftDate, String start, String end) {
        this.employee = employee;
        this.shiftDate = shiftDate;
        this.start = start;
        this.end = end;
    }

    public String getEmployeeByName() {
        return this.employee.getName();
    }
    
    public String getEmployeeByID () {
        return this.employee.getID();
    }

    public String getStart() {
        return this.start;
    }

    public String getEnd() {
        return this.end;
    }

    public String getDate() {
        return this.shiftDate;
    }

    @Override
    public String toString() {
        return "Name: " + getEmployeeByName() + ",\nDate: " + getDate() + ",\nShift: " + getStart() + " - " + getEnd() + "\n";
    }

}
